﻿Write-Host "Deployment Started! Please wait..."
$RootPath = $PSScriptRoot



Import-Module webAdministration


function Create-IISAppPool($iisAppPoolName,$iisAppPoolDotNetVersion){
cd IIS:\AppPools\
if (!(Test-Path $iisAppPoolName -pathType container)){
$appPool = New-Item  $iisAppPoolName 
$appPool | Set-ItemProperty  -Name "managedRuntimeVersion" -Value $iisAppPoolDotNetVersion
}
cd c:
}


function Create-IISSite($iisAppPoolName,$iisSiteName,$bindPort){
#cd IIS:\Sites\
$SitePath=$RootPath+"\"+$iisSiteName
if (!(Test-Path $iisSiteName -pathType container)){
$iisApp=New-Item -path "IIS:\Sites" -Name $iisSiteName -Type Site -Bindings @{protocol="http";bindingInformation="*:"+$bindPort+":"}
$iisApp | Set-ItemProperty -name "physicalPath" -value $SitePath
$iisApp | Set-ItemProperty -name "applicationPool" -value $iisAppPoolName
}
Write-Host $iisSiteName" started and running on port http://localhost:"$bindPort
#cd C:\WINDOWS\system32\
}

Create-IISAppPool -iisAppPoolName "1.TwinWorXServiceRegistery" -iisAppPoolDotNetVersion "v4.0"
Create-IISSite  -iisAppPoolName "1.TwinWorXServiceRegistery" -iisSiteName "1.TwinWorXServiceRegistery" -bindPort "1001"

Create-IISAppPool -iisAppPoolName "2.TwinWorXDataResourceMangaer" -iisAppPoolDotNetVersion "v4.0"
Create-IISSite  -iisAppPoolName "2.TwinWorXDataResourceMangaer" -iisSiteName "2.TwinWorXDataResourceMangaer" -bindPort "1002"

Create-IISAppPool -iisAppPoolName "3.TwinWorXDataAccessService" -iisAppPoolDotNetVersion "v4.0"
Create-IISSite  -iisAppPoolName "3.TwinWorXDataAccessService" -iisSiteName "3.TwinWorXDataAccessService" -bindPort "1003"

Create-IISAppPool -iisAppPoolName "4.TwinWorxDataAlarmingService" -iisAppPoolDotNetVersion "v4.0"
Create-IISSite  -iisAppPoolName "4.TwinWorxDataAlarmingService" -iisSiteName "4.TwinWorxDataAlarmingService" -bindPort "1004"

Create-IISAppPool -iisAppPoolName "5.TwinWorXHistoricalDataAccessService" -iisAppPoolDotNetVersion "v4.0"
Create-IISSite  -iisAppPoolName "5.TwinWorXHistoricalDataAccessService" -iisSiteName "5.TwinWorXHistoricalDataAccessService" -bindPort "1005"


Create-IISAppPool -iisAppPoolName "6.TwinWorXAlarmingLoggerService" -iisAppPoolDotNetVersion "v4.0"
Create-IISSite  -iisAppPoolName "6.TwinWorXAlarmingLoggerService" -iisSiteName "6.TwinWorXAlarmingLoggerService" -bindPort "1006"

Create-IISAppPool -iisAppPoolName "7.TwinWorXApiGateway" -iisAppPoolDotNetVersion "v4.0"
Create-IISSite  -iisAppPoolName "7.TwinWorXApiGateway" -iisSiteName "7.TwinWorXApiGateway" -bindPort "1007"

Create-IISAppPool -iisAppPoolName "8.TwinWorXDT" -iisAppPoolDotNetVersion "v4.0"
Create-IISSite  -iisAppPoolName "8.TwinWorXDT" -iisSiteName "8.TwinWorXDT" -bindPort "1008"

Write-Host "Deployment of microservices has been Completed!"



